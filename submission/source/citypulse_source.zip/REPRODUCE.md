# Reproducing the CityPulse frozen decision audit

This archive is an anonymised copy of the **committed** source tree of the CityPulse project at
`HEAD` = `4fe70e01f66955ef087e25986da78f99aa23ca49` (`git archive`, 2026-10-06). It contains the code, the frozen scenario assets and
the recorded frozen-audit outputs. Every entry was scanned for identifying information (user
names, e-mail addresses, Windows user-profile paths, school names, author lines): the archive
contains none, so no file was rewritten and every byte matches the committed tree, which is what
lets the sha256 values in `results/freeze/freeze_manifest.json` be re-checked.

**The reproduction route is step 1 below**, the independent recomputation of the estimands from
`results/frozen_audit/raw.parquet`. The packaged production analyzer refuses to run on the frozen
seeds off the collection host, by design; section 6 explains the gate and why.

## 1. Contents

| Path | What it is |
| --- | --- |
| `citypulse/` | project package: twin, proxy, event engine, bounded-demand network, experiments |
| `tests/` | pytest suite (`pytest.ini` sets `testpaths = tests`) |
| `scenarios/kwuntong/blite/` | frozen scenario assets: `net5.net.xml`, `detectors5.add.xml`, `detector_map.json`, `synth5/` demand + signal plans |
| `scenarios/kwuntong/vtypes_*.add.xml` | vehicle-type definitions used by both worlds |
| `final/` | final report, claims, method, figures, tables, demo decision cards |
| `results/frozen_audit/raw.parquet` | the 960 frozen branch rows (8 seeds x 2 beliefs x 6 replications x 5 actions, plus the proxy and calibration rows) - the only input of step 1 |
| `results/frozen_audit/metrics.json` | every estimand the production analyzer produced; the reference values step 1 is checked against |
| `results/frozen_audit/state_history.parquet`, `results/frozen_audit/rng_check.json` | the snapshot comparison and the recorded RNG-isolation check |
| `results/frozen_audit/report.md` | the report the analyzer wrote next to `metrics.json` |
| `results/frozen_audit/provenance.json` | collection provenance: git head, file hashes, effective command lines, runtime environment, collection fingerprint |
| `results/frozen_audit/code_hashes_before_after.json` | sha256 of every `citypulse/**/*.py` before and after the branch runs (`match: true`) |
| `results/frozen_audit/seed_check.json` | the preregistered seed-hygiene scan of the frozen seeds (`passed: true`, no foreign seed found) |
| `results/frozen_audit/crosscheck_claude/` | **the independent recomputation**: `indep_audit.py` (recomputes every estimand from `raw.parquet`, imports no project code), its recorded output `output.txt`, and the per-seed diff against `metrics.json` (`compare.py`, `compare_output.txt`, `compare_per_seed.csv`) |
| `results/frozen_audit/crosscheck_agypro/` | a second, separately written recomputation (`crosscheck.py`, `compare.py`, `per_seed.csv`, `summary.json`, `summary.md`) |
| `results/freeze/freeze_manifest.json` | design-freeze record: sha256 of all code and assets, environment, package versions |
| `docs/freeze-2026-10-06.md`, `docs/oct16-frozen-audit-plan.md` | the frozen method and the preregistered audit protocol |

## 2. Environment

The freeze ran on Windows 11 with **CPython 3.12.13** and **SUMO 1.27.1**
(`eclipse-sumo`, `libsumo`, `sumolib`, `sumo-data`, `traci`, all 1.27.1); the pinned versions are
in `requirements.txt` and in `results/freeze/freeze_manifest.json` (`packages`).

```bash
# Python 3.12
python -m venv .venv
. .venv/bin/activate            # Windows: .venv\Scripts\activate
pip install -r requirements.txt # installs SUMO 1.27.1 wheels + pinned analysis stack
```

SUMO itself is installed by the `eclipse-sumo` wheel; `SUMO_HOME` is not required for the
`libsumo`-based runs, but setting it to the wheel's `sumo` directory helps the command-line tools.

## 3. Environment variables (frozen values)

```bat
set CITYPULSE_NET=blite
set CITYPULSE_BLITE_REV=5
set CITYPULSE_REROUTE=0
set OPENBLAS_NUM_THREADS=1
set PYTHONDONTWRITEBYTECODE=1
```

```bash
export CITYPULSE_NET=blite CITYPULSE_BLITE_REV=5 CITYPULSE_REROUTE=0 \
       OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
```

## 4. Tests

```bash
python -m pytest -q
```

The frozen commit recorded **222 passed, 3 skipped** (the three skips are SUMO-integration tests
that need a full SUMO installation). Test seeds 6001-6008 stay reserved and unused.

## 5. Reproduction route: independent recomputation (step 1)

The production analyzer is gated on the collection environment and refuses to run on the frozen
seeds (section 6), so the documented route is the independent recomputation, which imports nothing
from `citypulse/` and needs only `pandas` + `pyarrow` (both installable from `requirements.txt`).

**Step 1.** From the root of the extracted archive:

```bash
python results/frozen_audit/crosscheck_claude/indep_audit.py results/frozen_audit/raw.parquet belief=B
python results/frozen_audit/crosscheck_claude/indep_audit.py results/frozen_audit/raw.parquet belief=D300
```

`indep_audit.py` opens `results/frozen_audit/raw.parquet` (its only input) and nothing else: it
re-derives the split-sample action choice `a*` from replications 1-3, the held-out benefits from
replications 4-6, the calibration floor from replications 7-12, and the pooled estimands, per seed
and pooled, for the requested belief. The pooled block it prints must equal the `pooled` block of
`results/frozen_audit/metrics.json` for that belief, to the printed digits (see the note on the
confidence bounds below).

Expected stdout for `belief=B` (`metrics.json` -> `primary`), rebuilt from that file with the
script's own formatting:

```
BEE           mean +2.162  CI [1.738, 2.586]  n=8
regret        mean -0.034  CI [-0.113, 0.046]  n=8
spearman      mean +0.825  CI [0.738, 0.912]  n=8
kendall       mean +0.675  CI [0.551, 0.799]  n=8
BEE_rel       mean +0.019  CI [0.015, 0.023]  n=8
regret_rel    mean -0.007  CI [-0.024, 0.01]  n=8
floor_signed  mean +0.170  CI [-0.13, 0.47]  n=8
G_T_A3        mean +7.066  CI [6.647, 7.484]  n=8
G_P_A3        mean +4.904  CI [4.569, 5.239]  n=8
floor_abs     mean 0.316 CI [0.134, 0.499]
BEE_abs       mean 2.162 CI [1.738, 2.586]
```

Expected stdout for `belief=D300` (`metrics.json` -> `secondary`):

```
BEE           mean -2.870  CI [-4.914, -0.825]  n=8
regret        mean +1.804  CI [-0.282, 3.891]  n=8
spearman      mean -0.350  CI [-0.629, -0.071]  n=8
kendall       mean -0.275  CI [-0.493, -0.057]  n=8
BEE_rel       mean -0.025  CI [-0.043, -0.007]  n=8
regret_rel    mean +0.377  CI [-0.058, 0.812]  n=8
floor_signed  mean +0.170  CI [-0.13, 0.47]  n=8
G_T_A3        mean +0.212  CI [-0.175, 0.599]  n=8
G_P_A3        mean +4.904  CI [4.569, 5.239]  n=8
floor_abs     mean 0.316 CI [0.134, 0.499]
BEE_abs       mean 2.884 CI [0.855, 4.913]
```

Two notes on the printed digits. Every mean is exactly the `pooled` mean in `metrics.json`.
`indep_audit.py` computes its confidence intervals with its own rounded t table (`T95[7] = 2.365`)
rather than the exact t quantile behind `metrics.json`'s `ci95_t`, so for `belief=D300` the printed
BEE upper bound is `-0.825` where `metrics.json` records `-0.826`, and `BEE_abs` prints `4.913`
where `metrics.json` records `4.912`; every other bound agrees to the printed digit. The script also
prints rounded floats, so CI bounds appear as `0.01` or `-0.13` rather than `0.010` / `-0.130`.

The seed-level selection lines it prints just above those blocks:

```
N 8 a* counts {'A3': 8} oracle {'A3': 7, 'A4': 1} top1 7
N 8 a* counts {'A3': 5, 'A0': 2, 'A1': 1} oracle {'A3': 7, 'A4': 1} top1 5
```

Headline values as recorded in `results/frozen_audit/metrics.json` (mean [95% t CI], n = 8):

| Estimand (`metrics.json` key) | `B` (primary) | `D300` (secondary) |
| --- | --- | --- |
| pooled split-sample BEE (primary estimand) (`BEE_signed`) | 2.162 [1.738, 2.586] | -2.870 [-4.914, -0.826] |
| pooled absolute BEE (`BEE_abs`) | 2.162 [1.738, 2.586] | 2.884 [0.855, 4.912] |
| twin benefit `G_T` (`G_T_hat`) | 7.066 [6.647, 7.484] | 0.196 [-0.165, 0.557] |
| proxy benefit `G_P` (`G_P`) | 4.904 [4.569, 5.239] | 3.066 [0.902, 5.230] |
| regret of `a*` against the proxy oracle (`Regret`) | -0.034 [-0.113, 0.046] | 1.804 [-0.282, 3.891] |
| Spearman rho, twin vs proxy ranking (`spearman_rho`) | 0.825 [0.738, 0.912] | -0.350 [-0.629, -0.071] |
| Kendall tau, twin vs proxy ranking (`kendall_tau`) | 0.675 [0.551, 0.799] | -0.275 [-0.493, -0.057] |
| top-1 agreement with the oracle (`top1_agree`) | 0.875 [0.579, 1.171] | 0.625 [0.192, 1.058] |
| calibration floor (signed) (`BEE_floor_signed`) | 0.170 [-0.130, 0.470] | 0.170 [-0.130, 0.470] |
| calibration floor (absolute) (`BEE_floor_abs`) | 0.316 [0.134, 0.499] | 0.316 [0.134, 0.499] |

The primary headline is the pooled split-sample BEE, `2.162 [1.738, 2.586]`; the recorded analyzer line was
`analyze: 8 seeds (frozen manifest 4501-4508); primary complete 8, secondary complete 8; BEE(B) = 2.162 [1.738, 2.586]`.

**Step 2 (cross-check, optional).** `compare.py` recomputes the same quantities and diffs all 160
per-seed values (8 seeds x 2 beliefs x 10 metrics) against `metrics.json`, writing
`compare_per_seed.csv` next to itself:

```bash
python results/frozen_audit/crosscheck_claude/compare.py
```

Expected stdout (recorded in `crosscheck_claude/compare_output.txt`):

```
compared 160 per-seed values; max abs diff 2.842e-14; mismatches 0
ALL MATCH
```

`crosscheck_agypro/` holds a second recomputation written independently of the first, with the same
result. Its two scripts hard-code the collection machine's absolute paths, so they are shipped as
recorded evidence (`per_seed.csv`, `summary.json`, `summary.md`) rather than as a portable command.

## 6. The production analyzer and its RNG gate

The recorded analyzer command was:

```bash
python -m citypulse.experiments.frozen_audit_analyze analyze --dir results/frozen_audit
```

It is gated: before computing or writing anything it calls `frozen_audit.verify_rng_binding`, which
requires `rng_check.json` to still bind, byte for byte,

1. the sha256 of `results/frozen_audit/provenance.json`;
2. a collection fingerprint - the sha256 over the hashes of every `citypulse/**/*.py` file, the
   hashes of the frozen assets listed in `results/freeze/freeze_manifest.json`, and the collection's
   runtime environment (interpreter version, package set, the `CITYPULSE_*` / `OPENBLAS_NUM_THREADS`
   / `PYTHONDONTWRITEBYTECODE` variables);
3. the sha256 of the three per-seed snapshots under `results/frozen_audit/runs/seed_4501/`
   (`twin/twin_state_5100.xml.gz`, `twin/twin_state_5100.json`, `proxy/proxy_state_5100.xml.gz`).

The recorded fingerprint is `b58f1711ab4ad7d5716fcddd80d784c77df0990ee1cca186c55c56c490177a78`, and `rng_check.json` binds `provenance.json` at
`fb6b0d66f8aa6f8707e6367edb6bd1aa65ecb6fa0ac0d7fd57ecca9d8ec8d843`, the sha256 of the CRLF checkout the collection ran on.

Run from this archive the gate stops at that first check, because `git archive` exports the LF blob
of `provenance.json` (the same line-ending artefact the manifest check reports as "match after
LF/CRLF normalisation"): the packaged file hashes to `a94ba3cc946d464035f577c36ac6ca2728d7028cf415f8bbf525933ea4cdae19`, so the command prints

```
Refusing to write production metrics: stale provenance: rng_check.json binds provenance.json 'fb6b0d66f8aa6f8707e6367edb6bd1aa65ecb6fa0ac0d7fd57ecca9d8ec8d843', current file is a94ba3cc946d464035f577c36ac6ca2728d7028cf415f8bbf525933ea4cdae19
```

exits with code 2 and writes neither `metrics.json` nor `report.md`. On a checkout that keeps the
original line endings that check passes and the next one stops the run instead, because the
fingerprint covers the collection host's interpreter, its package set and the three per-seed
snapshots under `runs/seed_4501/`, none of which are redistributed here:

```
Refusing to write production metrics: stale fingerprint: rng_check.json records '<recorded>', current collection fingerprint is '<recomputed>'
```

Either way the gate arms itself whenever seeds 4501-4508 are requested or are present in the raw
rows, and `--selftest` cannot bypass it for them: any run over the frozen seeds is refused.

That refusal is the designed behaviour, not a broken package, and it is exactly why the
recomputation in section 5 - not the analyzer - is the documented reproduction route: the gate
protects the production numbers from being regenerated outside the environment that produced them,
while `raw.parquet` carries every input the estimands need, so an independent implementation can
derive them anywhere. `metrics.json` is shipped as the analyzer's recorded output and step 1 shows
that its values follow from `raw.parquet` alone.

## 7. Integrity

`results/freeze/freeze_manifest.json` lists the sha256 of every `citypulse/**/*.py` file
(`sha256_code`) and of the fifteen frozen assets (`sha256_assets`). The copies in this archive are
byte-identical to the committed tree at `4fe70e01f66955ef087e25986da78f99aa23ca49`; the packaging step verified each included
manifest hash and reports the result in `submission/source/anonymity_scan.md`.
